﻿using System.ComponentModel;
using System.Runtime.CompilerServices;
namespace ViewModel
{
    public interface IViewModel : INotifyPropertyChanged
    {
        event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Оповещение об изменении свойства
        /// </summary>
        /// <param name="prop">Название изменённого свойства</param>
        void OnPropertyChanged([CallerMemberName] string prop = "");

        /// <summary>
        /// Проверка текстовых полей на null
        /// </summary>
        /// <param name="name">Имя студента</param>
        /// <param name="group">Группа студента</param>
        /// <param name="speciality">Специальность студента</param>
        void checkTextboxes(string name, string group, string speciality);

        /// <summary>
        /// Обновление в коллекции студентов и статистических данных для гистограммы
        /// </summary>
        void DataUpdate();
    }
}
