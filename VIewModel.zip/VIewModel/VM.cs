﻿using BL;
using Model;
using Ninject;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using VIewModel;
namespace ViewModel
{
    public class VM : IViewModel
    {
        IBussinessLogic logic = null;

        /// <summary>
        /// Конструктор
        /// </summary>
        public VM()
        {
            IKernel ninjectKernel = new StandardKernel(new SimpleConfigModule());
            this.logic = ninjectKernel.Get<IBussinessLogic>();
            StudentsId = new ObservableCollection<int>();
            DataUpdate();

            foreach (Student student in Students)
            {
                StudentsId.Add(student.Id);
            }
        }

        private Commands removeCommand;
        /// <summary>
        /// Удаление студента
        /// </summary>
        public Commands RemoveCommand
        {
            get
            {
                return removeCommand ??
                  (removeCommand = new Commands(obj =>
                  {
                      if (FindId != -1)
                      {
                          logic.RemoveStudent(FindId);
                          StudentsId.Remove(FindId);
                          DataUpdate();
                          FindId = new int();
                      }
                  }));
            }
        }

        private Commands addCommand;
        /// <summary>
        /// Добавление студента
        /// </summary>
        public Commands AddCommand
        {
            get
            {
                return addCommand ??
                  (addCommand = new Commands(obj =>
                  {
                      logic.AddStudent(Name, Group, Speciality);
                      StudentsId.Add(Students.LastOrDefault().Id+1);
                      DataUpdate();
                      Name = null;
                      Group = null;
                      Speciality = null;
                  }));
            }
        }

        private Commands changeCommand;
        /// <summary>
        /// Изменение студента
        /// </summary>
        public Commands ChangeCommand
        {
            get
            {
                return changeCommand ??
                    (changeCommand = new Commands(obj =>
                    {
                        logic.ChangeStudent(FindId, Name, Group, Speciality);
                        DataUpdate();
                        FindId = new int();
                        Name = null;
                        Group = null;
                        Speciality = null;
                        ExistId = new bool();
                    }));
            }
        }

        private Commands findCommand;
        /// <summary>
        /// Поиск студента
        /// </summary>
        public Commands FindCommand
        {
            get
            {
                return findCommand ??
                    (findCommand = new Commands(obj =>
                    {
                        ExistId = logic.FindStudent(FindId);
                    }));
            }
        }

        /// <summary>
        /// Коллекция студентов
        /// </summary>
        private ObservableCollection<Student> students;
        public ObservableCollection<Student> Students
        {
            get { return students; }
            set
            {
                students = value;
                OnPropertyChanged("Students");
            }
        }

        /// <summary>
        /// Студент по идентификатору
        /// </summary>
        private ObservableCollection<int> studentsId;
        public ObservableCollection<int> StudentsId
        {
            get { return studentsId; }
            set
            {
                studentsId = value;
                OnPropertyChanged("StudentsId");
            }
        }

        private string group;
        public string Group
        {
            get { return group; } 
            set 
            {
                group = value;
                checkTextboxes(Name, group, speciality);
                OnPropertyChanged("Group");
            }
        }

        private string speciality;
        public string Speciality
        {
            get { return speciality; }
            set
            {
                speciality = value;
                checkTextboxes(Name, Group, speciality);
                OnPropertyChanged("Speciality");
            }
        }

        private bool addButton = false;
        public bool AddButton
        {
            get { return addButton; }
            set
            {
                addButton = value;
                OnPropertyChanged("AddButton");
            }
        }

        private bool existId = false;
        public bool ExistId
        {
            get { return existId; }
            set
            {
                existId = value;
                OnPropertyChanged("ExistId");
            }
        }

        private int findId = -1;
        public int FindId
        {
            get { return findId; }
            set
            {
                findId = value;
                OnPropertyChanged("FindId");
            }
        }

        private Dictionary<string, int> statistic;
        public Dictionary<string, int> Statistic
        {
            get { return statistic; }
            set
            { 
                statistic = value;
                OnPropertyChanged("Statistic");
            }
        }

        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                checkTextboxes(name, group, Speciality);
                OnPropertyChanged("Name");
            }
        }

        /// <summary>
        /// Проверка текстового поля на null
        /// </summary>
        /// <param name="name">Имя студента</param>
        /// <param name="group">Группа студента</param>
        /// <param name="speciality">Специальность студента</param>
        public void checkTextboxes(string name, string group, string speciality)
        {
            if(string.IsNullOrEmpty(name) || string.IsNullOrEmpty(group) || string.IsNullOrEmpty(speciality))
            {
                AddButton = false;
            }
            else
            {
                AddButton = true;
            }
        }

        /// <summary>
        /// Обновление в коллекции студентов и статистических данных
        /// </summary>
        public void DataUpdate()
        {
            Statistic = logic.GetGistogrammStatistic();
            Students = new ObservableCollection<Student>(logic.GetAll());
        }

        public event PropertyChangedEventHandler PropertyChanged;
        /// <summary>
        /// Оповещение об изменении свойств
        /// </summary>
        /// <param name="prop">Измененное свойство</param>
        public void OnPropertyChanged([CallerMemberName] string prop = "")
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(prop));
        }
    }
}
