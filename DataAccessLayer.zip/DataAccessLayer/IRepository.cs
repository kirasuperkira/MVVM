﻿using Model;
using System.Collections.Generic;

namespace DataAccessLayer
{
    public interface IRepository<T> where T : class, IDomainObject, new()
    {
        /// <summary>
        /// Добавление объекта в репозиторий
        /// </summary>
        /// <param name="obj">Добавленный объект</param>
        void Create(T obj);

        /// <summary>
        /// Удаление объекта из репозитория
        /// </summary>
        /// <param name="id">ID удаленного объекта</param>
        void Delete(int id);

        /// <summary>
        /// Изменение объекта в репозитории
        /// </summary>
        /// <param name="obj">Измененный объект</param>
        void Update(T obj);

        /// <summary>
        /// Получение объекта из репозитория
        /// </summary>
        /// <param name="id">ID полученного объекта</param>
        /// <returns></returns>
        T Read(int id);

        /// <summary>
        /// Получения всех объектов из репозитория
        /// </summary>
        /// <returns></returns>
        IEnumerable<T> GetAll();
    }
}
