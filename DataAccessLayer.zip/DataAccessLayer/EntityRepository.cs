﻿using Model;
using System;
using System.Collections.Generic;
namespace DataAccessLayer
{
    public class EntityRepository<T> : IRepository<T> where T : class, IDomainObject, new()
    {
        DBContext dbContext;
        /// <summary>
        /// Конструктор
        /// </summary>
        public EntityRepository()
        {
            dbContext = new DBContext();
        }

        /// <summary>
        /// Добавление объекта в контекст
        /// </summary>
        /// <param name="obj">Добавленный объект</param>
        public void Create(T obj)
        {
            dbContext.Set<T>().Add(obj);
            SaveChanges();
        }

        /// <summary>
        /// Удаление объекта из контекста
        /// </summary>
        /// <param name="id">ID удаленного объекта</param>
        public void Delete(int id)
        {
            dbContext.Set<T>().Remove(dbContext.Set<T>().Find(id));
            SaveChanges();
        }

        /// <summary>
        /// Изменение объекта в контексте
        /// </summary>
        /// <param name="obj">Измененный объект</param>
        public void Update(T obj)
        {
            dbContext.Entry(Read(obj.Id)).CurrentValues.SetValues(obj);
            SaveChanges();
        }

        /// <summary>
        /// Получение объекта из контекста
        /// </summary>
        /// <param name="id">ID</param>
        /// <returns></returns>
        /// <exception cref="Exception">Ошибка, если объект отсутствует в контексте/exception>
        public T Read(int id)
        {
            if (dbContext.Set<T>().Find(id) == null)
            {
                throw new Exception();
            }
            return dbContext.Set<T>().Find(id);
        }

        /// <summary>
        /// Получение всех объектов из контекста
        /// </summary>
        /// <returns>Полученные из контекста объекты</returns>
        public IEnumerable<T> GetAll()
        {
            return dbContext.Set<T>();
        }

        /// <summary>
        /// Сохранение изменений
        /// </summary>
        private void SaveChanges()
        {
            dbContext.SaveChanges();
        }
    }
}
