﻿using Model;
using System.Data.Entity;

namespace DataAccessLayer
{
    public class DBContext : DbContext
    {
        public DbSet<Student> Students { get; set; }
        public DBContext() : base("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Кира\\source\\repos\\АИС\\lab5\\DataAccessLayer\\Database1.mdf;Integrated Security=True")
        {
        }
    }
}
