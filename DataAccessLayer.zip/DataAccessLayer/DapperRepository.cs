﻿using Dapper;
using Model;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
namespace DataAccessLayer
{
    public class DapperRepository<T> : IRepository<T> where T : class, IDomainObject, new()
    {
        static string connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\Кира\\source\\repos\\АИС\\lab5\\DataAccessLayer\\Database1.mdf;Integrated Security=True";

        /// <summary>
        /// Создание объекта (запрос)
        /// </summary>
        /// <param name="t">Созданный объект</param>
        public void Create(T t)
        {
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                var sqlQuery = "INSERT INTO Students (Name,[Group],Speciality) VALUES(@Name, @Group,@Speciality); SELECT CAST(SCOPE_IDENTITY() as int)";
                int StudentId = db.Query<int>(sqlQuery, t).FirstOrDefault();
                t.Id = StudentId;
            }
        }

        /// <summary>
        /// Обновление объекта (запрос)
        /// </summary>
        /// <param name="t">Измененный объект</param>
        public void Update(T t)
        {
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                var sqlQuery = "UPDATE Students SET Name = @Name, Speciality = @Speciality, [Group] = @Group WHERE Id = @Id";
                db.Execute(sqlQuery, t);
            }
        }

        /// <summary>
        /// Удаление объекта (запрос)
        /// </summary>
        /// <param name="id">ID удаленного объекта</param>
        public void Delete(int id)
        {
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                var sqlQuery = "DELETE FROM Students WHERE Id = @id";
                db.Execute(sqlQuery, new { id });
            }
        }

        /// <summary>
        /// Получение объекта из базы данных (запрос)
        /// </summary>
        /// <param name="id">ID объекта, который необходимо получить</param>
        /// <returns></returns>
        public T Read(int id)
        {
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                return db.Query<T>("SELECT * FROM Students WHERE Id = @id", new { id }).First();
            }
        }

        /// <summary>
        /// Получение всех объектов из базы данных (запрос)
        /// </summary>
        /// <returns>Перечислитель объектов</returns>
        public IEnumerable<T> GetAll()
        {
            using (IDbConnection db = new SqlConnection(connectionString))
            {
                return db.Query<T>("SELECT * FROM Students");
            }
        }
    }
}
