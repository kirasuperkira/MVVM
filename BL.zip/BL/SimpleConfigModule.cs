﻿using DataAccessLayer;
using Model;
using Ninject.Modules;
namespace BL
{
    public class SimpleConfigModule : NinjectModule
    {
        public override void Load()
        {
            //Bind<IRepository<Student>>().To<EntityRepository<Student>>().InSingletonScope();
            Bind<IRepository<Student>>().To<DapperRepository<Student>>().InSingletonScope();
            Bind<IBussinessLogic>().To<BussinessLogic>().InSingletonScope();
        }
    }
}
