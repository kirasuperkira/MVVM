﻿using DataAccessLayer;
using Model;
using System;
using System.Collections.Generic;
namespace BL
{
    public class BussinessLogic : IBussinessLogic
    {
        public event Action DataChanged;
        public IRepository<Student> Repository { get; set; }
        public BussinessLogic(IRepository<Student> repository)
        {
            Repository = repository;
        }

        /// <summary>
        /// Добавление студента
        /// </summary>
        /// <param name="name">Имя нового студента</param>
        /// <param name="group">Группа нового студента</param>
        /// <param name="speciality">Специальность нового студента</param>
        public void AddStudent(string name, string group, string speciality)
        {
            Student student = new Student()
            {
                Name = name,
                Group = group,
                Speciality = speciality
            };
            Repository.Create(student);
            invokeDataChanged();
        }

        /// <summary>
        /// Удаление студента
        /// </summary>
        /// <param name="id">ID студента, которого необходимо удалить</param>
        public void RemoveStudent(int id)
        {
            Repository.Delete(id);
            invokeDataChanged();
        }

        /// <summary>
        /// Изменение студента
        /// </summary>
        /// <param name="id">ID студента, которого необходимо изменить</param>
        /// <param name="name">Имя студента, которого необходимо изменить</param>
        /// <param name="group">Группа студента, которого необходимо изменить</param>
        /// <param name="speciality">Специальность студента, которого необходимо изменить</param>
        public void ChangeStudent(int id, string name, string group, string speciality)
        {
            Student student = Repository.Read(id);
            if (name != null)
            {
                student.Name = name;
            }
            if (group != null)
            {
                student.Group = group;
            }
            if (speciality != null)
            {
                student.Speciality = speciality;
            }
            Repository.Update(student);
            invokeDataChanged();
        }

        /// <summary>
        /// Отображение списка студентов
        /// </summary>
        /// <returns>Список студентов или сообщение об ошибке</returns>
        public IEnumerable<Student> GetAll()
        {
            return Repository.GetAll();
        }

        /// <summary>
        /// Сбор статистических данных для гистограммы
        /// </summary>
        /// <returns>Статистические данные</returns>
        public Dictionary<string, int> GetGistogrammStatistic()
        {
            int PeopleInGroup = 1;
            IEnumerable<Student> students = Repository.GetAll();
            Dictionary<string, int> Statistic = new Dictionary<string, int>();
            foreach (Student student1 in students)
            {
                if (!Statistic.ContainsKey(student1.Speciality))
                {
                    foreach (Student student2 in students)
                    {
                        if (student1.Speciality == student2.Speciality && student1.Id != student2.Id)
                        {
                            PeopleInGroup++;
                        }
                    }
                    Statistic.Add(student1.Speciality, PeopleInGroup);
                    PeopleInGroup = 1;
                }
            }
            return Statistic;
        }

        /// <summary>
        /// Поиск студента по ID
        /// </summary>
        /// <param name="id">ID студента</param>
        /// <returns>Значение True (False), если студент присутствует в списке (отсутствует в списке)</returns>
        public bool FindStudent(int id)
        {
            try
            {
                Repository.Read(id);
                return true;
            }
            catch { return false; }
        }

        /// <summary>
        /// Вызов события на событие DataChanged
        /// </summary>
        private void invokeDataChanged()
        {
            DataChanged?.Invoke();
        }
    }
}
