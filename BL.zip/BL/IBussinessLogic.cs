﻿using Model;
using System;
using System.Collections.Generic;

namespace BL
{
    public interface IBussinessLogic
    {
        event Action DataChanged;

        /// <summary>
        /// Добавление студента
        /// </summary>
        /// <param name="name">Имя нового студента</param>
        /// <param name="group">Группа нового студента</param>
        /// <param name="speciality">Специальность нового студента</param>
        void AddStudent(string name, string group, string speciality);

        /// <summary>
        /// Удаление студента
        /// </summary>
        /// <param name="id">ID студента, которого необходимо удалить</param>
        void RemoveStudent(int id);

        /// <summary>
        /// Изменение студента
        /// </summary>
        /// <param name="id">ID студента, которого необходимо изменить</param>
        /// <param name="name">Имя студента, которого необходимо изменить</param>
        /// <param name="group">Группа студента, которого необходимо изменить</param>
        /// <param name="speciality">Специальность студента, которого необходимо изменить</param>
        void ChangeStudent(int id, string name, string group, string speciality);

        /// <summary>
        /// Получение списка студентов
        /// </summary>
        /// <returns>Список студентов (или вывод об ошибке)</returns>
        IEnumerable<Student> GetAll();

        /// <summary>
        /// Сбор статистических данных для гистограммы
        /// </summary>
        /// <returns>Статистические данные</returns>
        Dictionary<string, int> GetGistogrammStatistic();

        /// <summary>
        /// Поиск студента по ID
        /// </summary>
        /// <param name="id">ID студента</param>
        /// <returns>Значение True (False), если студент присутствует в списке (отсутствует в списке)</returns>
        bool FindStudent(int id);
    }
}
